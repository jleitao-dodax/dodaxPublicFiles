# Just a stub, so we can correctly scope other classes.
module Puppet::Network # :nodoc:
end
